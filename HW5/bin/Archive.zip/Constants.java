// constants class
class Constants {

  // window width
  static int WIDTH = 600;
  // window height
  static int HEIGHT = 600;
  // word speed
  static int WORD_SPEED = 3;
  // tick tracker
  static int TICK = 3; 

}